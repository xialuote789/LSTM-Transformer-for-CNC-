"""
Module 1: Colab Environment Setup and Google Drive Data Verification
Purpose: Mount Google Drive and verify data structure
"""

import os
from pathlib import Path
import h5py
from google.colab import drive

# ============= Step 1: Mount Google Drive =============
print("=" * 80)
print("Step 1: Mounting Google Drive...")
print("=" * 80)

drive.mount("/content/drive")
print("Google Drive mounted successfully!\n")

# ============= Step 2: Define Data Path =============
print("=" * 80)
print("Step 2: Setting up data paths...")
print("=" * 80)

# Your Google Drive folder path
BASE_PATH = "/content/drive/MyDrive/CNC_Machining/data"

print(f"Base data path: {BASE_PATH}")
print(f"Path exists: {os.path.exists(BASE_PATH)}\n")

# ============= Step 3: Verify Data Structure =============
print("=" * 80)
print("Step 3: Verifying data structure...")
print("=" * 80)

def verify_data_structure(base_path):
    """
    Verify the data folder structure and H5 files
    """
    results = {
        "base_exists": False,
        "folders": {},
        "total_h5_files": 0,
        "sample_files": []
    }

    base_path = Path(base_path)

    # Check if base path exists
    if not base_path.exists():
        print(f"ERROR: Base path does not exist: {base_path}")
        return results

    results["base_exists"] = True
    print(f"✓ Base path exists: {base_path}\n")

    # Check for M01, M02, M03 folders
    for folder_name in ["M01", "M02", "M03"]:
        folder_path = base_path / folder_name

        if folder_path.exists():
            # Find all H5 files in this folder
            h5_files = list(folder_path.rglob("*.h5"))

            # Classify files as good or bad
            good_files = []
            bad_files = []

            for h5_file in h5_files:
                file_str = str(h5_file).lower()
                if "bad" in file_str or "worn" in file_str:
                    bad_files.append(h5_file.name)
                else:
                    good_files.append(h5_file.name)

            results["folders"][folder_name] = {
                "path": str(folder_path),
                "exists": True,
                "total_h5": len(h5_files),
                "good_files": len(good_files),
                "bad_files": len(bad_files),
                "sample_good": good_files[:3] if good_files else [],
                "sample_bad": bad_files[:3] if bad_files else []
            }

            results["total_h5_files"] += len(h5_files)

            # Store sample files for testing
            if h5_files:
                results["sample_files"].append(str(h5_files[0]))

            print(f"✓ Folder: {folder_name}")
            print(f"  Path: {folder_path}")
            print(f"  Total H5 files: {len(h5_files)}")
            print(f"  Good files: {len(good_files)}")
            print(f"  Bad files: {len(bad_files)}")
            if good_files:
                print(f"  Sample good files: {good_files[:3]}")
            if bad_files:
                print(f"  Sample bad files: {bad_files[:3]}")
            print()
        else:
            results["folders"][folder_name] = {
                "exists": False
            }
            print(f"✗ Folder NOT found: {folder_name}")
            print()

    return results

# Run verification
data_info = verify_data_structure(BASE_PATH)

# ============= Step 4: Test H5 File Reading =============
print("=" * 80)
print("Step 4: Testing H5 file reading...")
print("=" * 80)

def test_h5_reading(h5_path):
    """
    Test reading a single H5 file and display its structure
    """
    try:
        print(f"Testing file: {Path(h5_path).name}")
        print(f"Full path: {h5_path}\n")

        with h5py.File(h5_path, "r") as f:
            print("H5 File Structure:")
            print("-" * 60)

            def print_structure(name, obj):
                if isinstance(obj, h5py.Dataset):
                    print(f"  Dataset: {name}")
                    print(f"    Shape: {obj.shape}")
                    print(f"    Dtype: {obj.dtype}")
                elif isinstance(obj, h5py.Group):
                    print(f"  Group: {name}")

            f.visititems(print_structure)
            print("-" * 60)

            # Try to extract data
            print("\nAttempting to extract data...")
            data_arrays = []

            for key in f.keys():
                if isinstance(f[key], h5py.Dataset):
                    data = f[key][:]
                    print(f"  Key: {key}, Shape: {data.shape}, Dtype: {data.dtype}")

                    if len(data.shape) == 1:
                        data_arrays.append(data)
                    elif len(data.shape) == 2:
                        print(f"    2D data detected, extracting first 3 columns...")
                        for i in range(min(3, data.shape[1])):
                            data_arrays.append(data[:, i])

                    if len(data_arrays) >= 3:
                        break

            if data_arrays:
                print(f"\n✓ Successfully extracted {len(data_arrays)} data arrays")
                for i, arr in enumerate(data_arrays[:3]):
                    print(f"  Array {i+1}: Length={len(arr)}, Mean={arr.mean():.4f}, Std={arr.std():.4f}")
                return True
            else:
                print("\n✗ No data could be extracted")
                return False

    except Exception as e:
        print(f"\n✗ Error reading file: {e}")
        return False

# Test reading if we have sample files
if data_info["sample_files"]:
    print(f"Testing {len(data_info['sample_files'])} sample files...\n")

    for i, sample_file in enumerate(data_info["sample_files"][:3], 1):
        print(f"\n{'='*60}")
        print(f"Sample File {i}:")
        print(f"{'='*60}")
        test_h5_reading(sample_file)
else:
    print("No H5 files found to test.")

# ============= Step 5: Summary =============
print("\n" + "=" * 80)
print("VERIFICATION SUMMARY")
print("=" * 80)

if data_info["base_exists"]:
    print(f"✓ Base path accessible")
    print(f"✓ Total H5 files found: {data_info['total_h5_files']}")
    print(f"\nFolder breakdown:")
    for folder_name, info in data_info["folders"].items():
        if info.get("exists"):
            print(f"  {folder_name}: {info['total_h5']} files ({info['good_files']} good, {info['bad_files']} bad)")
        else:
            print(f"  {folder_name}: NOT FOUND")

    if data_info["total_h5_files"] > 0:
        print(f"\n✓ Data verification SUCCESSFUL!")
        print(f"✓ Ready to proceed to Module 2 (Data Loading)")
    else:
        print(f"\n✗ No H5 files found. Please check the data path.")
else:
    print(f"✗ Base path not accessible")
    print(f"Please verify the path: {BASE_PATH}")

print("=" * 80)