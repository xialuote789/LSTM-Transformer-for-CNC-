"""
Module 4: Training and Evaluation Framework
Purpose: Train and evaluate all models with knowledge distillation support
Features:
- Standard training loop
- Knowledge distillation for student model
- Comprehensive evaluation metrics
- Early stopping
- GPU optimization for A100
- Progress tracking
"""

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import numpy as np
import time
from sklearn.metrics import (
    f1_score,
    precision_score,
    recall_score,
    accuracy_score,
    roc_auc_score,
    confusion_matrix
)

# ============= Training Configuration =============
class TrainConfig:
    """Training configuration"""
    EPOCHS = 20
    LEARNING_RATE = 1e-3
    WEIGHT_DECAY = 1e-4
    EARLY_STOPPING_PATIENCE = 5

    # Knowledge Distillation parameters
    KD_TEMPERATURE = 3.0
    KD_ALPHA = 0.5  # Balance between KD loss and CE loss

    # Device
    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# ============= Standard Training Function =============
def train_epoch(model, train_loader, criterion, optimizer, device):
    """
    Train model for one epoch
    Returns: average loss
    """
    model.train()
    total_loss = 0

    for batch_x, batch_y in train_loader:
        batch_x = batch_x.to(device)
        batch_y = batch_y.to(device)

        # Forward pass
        optimizer.zero_grad()
        outputs = model(batch_x)
        loss = criterion(outputs, batch_y)

        # Backward pass
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    return total_loss / len(train_loader)

# ============= Knowledge Distillation Training =============
def train_epoch_with_kd(student_model, teacher_model, train_loader,
                        optimizer, device, temperature=3.0, alpha=0.5):
    """
    Train student model with knowledge distillation from teacher
    Args:
        student_model: Model being trained
        teacher_model: Pre-trained teacher model (frozen)
        train_loader: Training data loader
        optimizer: Optimizer
        device: Device
        temperature: Temperature for softening probabilities
        alpha: Balance between KD loss and CE loss
    Returns: average loss
    """
    student_model.train()
    teacher_model.eval()

    ce_criterion = nn.CrossEntropyLoss()
    kl_criterion = nn.KLDivLoss(reduction="batchmean")

    total_loss = 0

    for batch_x, batch_y in train_loader:
        batch_x = batch_x.to(device)
        batch_y = batch_y.to(device)

        optimizer.zero_grad()

        # Student forward pass
        student_outputs = student_model(batch_x)

        # Teacher forward pass (no gradients)
        with torch.no_grad():
            teacher_outputs = teacher_model(batch_x)

        # Hard target loss (standard cross-entropy)
        ce_loss = ce_criterion(student_outputs, batch_y)

        # Soft target loss (knowledge distillation)
        student_soft = F.log_softmax(student_outputs / temperature, dim=1)
        teacher_soft = F.softmax(teacher_outputs / temperature, dim=1)
        kd_loss = kl_criterion(student_soft, teacher_soft) * (temperature ** 2)

        # Combined loss
        loss = alpha * kd_loss + (1 - alpha) * ce_loss

        # Backward pass
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    return total_loss / len(train_loader)

# ============= Validation Function =============
def validate(model, val_loader, criterion, device):
    """
    Validate model
    Returns: loss, f1_score, predictions, labels
    """
    model.eval()
    total_loss = 0
    all_preds = []
    all_labels = []

    with torch.no_grad():
        for batch_x, batch_y in val_loader:
            batch_x = batch_x.to(device)
            batch_y = batch_y.to(device)

            outputs = model(batch_x)
            loss = criterion(outputs, batch_y)

            preds = torch.argmax(outputs, dim=1)

            total_loss += loss.item()
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(batch_y.cpu().numpy())

    avg_loss = total_loss / len(val_loader)
    val_f1 = f1_score(all_labels, all_preds, average="binary")

    return avg_loss, val_f1, all_preds, all_labels

# ============= Main Training Function =============
def train_model(model, train_loader, val_loader, config=TrainConfig,
                use_kd=False, teacher_model=None, model_name="Model"):
    """
    Complete training loop with early stopping
    Args:
        model: Model to train
        train_loader: Training data loader
        val_loader: Validation data loader
        config: Training configuration
        use_kd: Whether to use knowledge distillation
        teacher_model: Teacher model (if using KD)
        model_name: Name for logging
    Returns: trained model, best_val_f1, training_history
    """
    print(f"\n{'='*60}")
    print(f"Training: {model_name}")
    print(f"{'='*60}")

    device = torch.device(config.DEVICE)
    model = model.to(device)

    # Setup optimizer and scheduler
    optimizer = optim.AdamW(
        model.parameters(),
        lr=config.LEARNING_RATE,
        weight_decay=config.WEIGHT_DECAY
    )
    scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer,
        T_max=config.EPOCHS
    )
    criterion = nn.CrossEntropyLoss()

    # Setup teacher model if using KD
    if use_kd:
        if teacher_model is None:
            print("Warning: KD requested but no teacher model provided")
            use_kd = False
        else:
            teacher_model = teacher_model.to(device)
            teacher_model.eval()
            print(f"Using Knowledge Distillation with temperature={config.KD_TEMPERATURE}")

    # Training tracking
    best_val_f1 = 0
    best_model_state = None
    patience_counter = 0
    history = {
        "train_loss": [],
        "val_loss": [],
        "val_f1": []
    }

    # Training loop
    start_time = time.time()

    for epoch in range(config.EPOCHS):
        # Training
        if use_kd:
            train_loss = train_epoch_with_kd(
                model, teacher_model, train_loader, optimizer, device,
                temperature=config.KD_TEMPERATURE, alpha=config.KD_ALPHA
            )
        else:
            train_loss = train_epoch(
                model, train_loader, criterion, optimizer, device
            )

        # Validation
        val_loss, val_f1, _, _ = validate(model, val_loader, criterion, device)

        # Update history
        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["val_f1"].append(val_f1)

        # Learning rate scheduling
        scheduler.step()

        # Check for improvement
        if val_f1 > best_val_f1:
            best_val_f1 = val_f1
            best_model_state = model.state_dict().copy()
            patience_counter = 0
        else:
            patience_counter += 1

        # Print progress every 5 epochs
        if (epoch + 1) % 5 == 0 or epoch == 0:
            print(f"Epoch {epoch+1:3d}/{config.EPOCHS}: "
                  f"Train Loss={train_loss:.4f}, "
                  f"Val Loss={val_loss:.4f}, "
                  f"Val F1={val_f1:.4f}, "
                  f"Best F1={best_val_f1:.4f}")

        # Early stopping
        if patience_counter >= config.EARLY_STOPPING_PATIENCE:
            print(f"Early stopping at epoch {epoch+1}")
            break

    training_time = time.time() - start_time

    # Load best model
    if best_model_state is not None:
        model.load_state_dict(best_model_state)

    print(f"Training completed in {training_time:.2f}s")
    print(f"Best validation F1: {best_val_f1:.4f}")

    return model, best_val_f1, history

# ============= Evaluation Function =============
def evaluate_model(model, test_loader, device="cuda", model_name="Model"):
    """
    Comprehensive evaluation of a model
    Returns: dict with all metrics
    """
    model.eval()
    model = model.to(device)

    all_preds = []
    all_labels = []
    all_probs = []
    inference_times = []

    with torch.no_grad():
        for batch_x, batch_y in test_loader:
            batch_x = batch_x.to(device)

            # Measure inference time
            start_time = time.time()
            outputs = model(batch_x)
            inference_time = (time.time() - start_time) / batch_x.size(0) * 1000  # ms per sample
            inference_times.append(inference_time)

            # Get predictions
            probs = F.softmax(outputs, dim=1)
            preds = torch.argmax(outputs, dim=1)

            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(batch_y.numpy())
            all_probs.extend(probs[:, 1].cpu().numpy())

    # Calculate metrics
    metrics = {
        "accuracy": accuracy_score(all_labels, all_preds),
        "precision": precision_score(all_labels, all_preds, average="binary", zero_division=0),
        "recall": recall_score(all_labels, all_preds, average="binary", zero_division=0),
        "f1_score": f1_score(all_labels, all_preds, average="binary", zero_division=0),
        "auc_roc": roc_auc_score(all_labels, all_probs),
        "inference_time_ms": np.mean(inference_times),
        "parameters": sum(p.numel() for p in model.parameters()),
        "confusion_matrix": confusion_matrix(all_labels, all_preds).tolist()
    }

    return metrics

# ============= Print Evaluation Results =============
def print_evaluation_results(metrics, model_name):
    """Pretty print evaluation results"""
    print(f"\n{model_name} Evaluation Results:")
    print(f"  Accuracy:  {metrics['accuracy']:.4f}")
    print(f"  Precision: {metrics['precision']:.4f}")
    print(f"  Recall:    {metrics['recall']:.4f}")
    print(f"  F1-Score:  {metrics['f1_score']:.4f}")
    print(f"  AUC-ROC:   {metrics['auc_roc']:.4f}")
    print(f"  Inference: {metrics['inference_time_ms']:.2f} ms/sample")
    print(f"  Confusion Matrix:")
    cm = np.array(metrics['confusion_matrix'])
    print(f"    [[TN={cm[0,0]:<6} FP={cm[0,1]:<6}]")
    print(f"     [FN={cm[1,0]:<6} TP={cm[1,1]:<6}]]")

# ============= Test Function =============
def test_training_pipeline():
    """Test the training and evaluation pipeline"""
    print("=" * 80)
    print("TESTING TRAINING PIPELINE")
    print("=" * 80)
    print()

    # Check device
    device = torch.device(TrainConfig.DEVICE)
    print(f"Using device: {device}")
    if torch.cuda.is_available():
        print(f"GPU: {torch.cuda.get_device_name(0)}")
        print(f"GPU Memory: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.2f} GB")
    print()

    # Create dummy data loaders
    print("Creating dummy data for testing...")
    from torch.utils.data import TensorDataset, DataLoader

    X_dummy = torch.randn(1000, 2000, 3)
    y_dummy = torch.randint(0, 2, (1000,))

    dummy_dataset = TensorDataset(X_dummy, y_dummy)
    dummy_loader = DataLoader(dummy_dataset, batch_size=32, shuffle=True)

    print(f"Dummy dataset: {len(dummy_dataset)} samples")
    print()

    # Test training a simple model
    print("Testing training with a simple model...")

    # Define a simple test model
    class TestModel(nn.Module):
        def __init__(self):
            super().__init__()
            self.gru = nn.GRU(3, 32, num_layers=1, batch_first=True)
            self.fc = nn.Linear(32, 2)

        def forward(self, x):
            _, h_n = self.gru(x)
            return self.fc(h_n.squeeze(0))

    model = TestModel()
    print(f"Model parameters: {sum(p.numel() for p in model.parameters()):,}")
    print()

    # Quick training test (2 epochs)
    config = TrainConfig()
    config.EPOCHS = 2

    trained_model, best_f1, history = train_model(
        model,
        dummy_loader,
        dummy_loader,
        config=config,
        model_name="SimpleGRU (Test)"
    )

    print(f"\nTraining history:")
    print(f"  Train losses: {history['train_loss']}")
    print(f"  Val F1 scores: {history['val_f1']}")
    print()

    # Test evaluation
    print("Testing evaluation...")
    metrics = evaluate_model(trained_model, dummy_loader, device=str(device), model_name="SimpleGRU")
    print_evaluation_results(metrics, "SimpleGRU (Test)")
    print()

    print("=" * 80)
    print("TRAINING PIPELINE TEST SUCCESSFUL!")
    print("=" * 80)
    print()
    print("✓ Training loop works correctly")
    print("✓ Validation works correctly")
    print("✓ Evaluation metrics computed correctly")
    print("✓ Ready to proceed to Module 5 (Full Training)")
    print()

# ============= Run Test =============
if __name__ == "__main__":
    test_training_pipeline()