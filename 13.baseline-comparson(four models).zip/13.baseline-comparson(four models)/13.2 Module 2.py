"""
Module 2: Efficient Data Loading and Preprocessing (Colab Optimized)
Purpose: Load H5 files from Google Drive and prepare for training on A100 GPU
Optimizations:
- Memory-efficient batch loading
- Smart sampling for large datasets (1702 files)
- Handles class imbalance
- GPU-optimized data structures
"""

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader, WeightedRandomSampler
from pathlib import Path
import h5py
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import warnings
warnings.filterwarnings("ignore")

# ============= Configuration =============
class DataConfig:
    """Data loading configuration"""
    # Path
    BASE_PATH = "/content/drive/MyDrive/CNC_Machining/data"

    # Window parameters
    WINDOW_SIZE = 2000
    STRIDE = 1000

    # Sampling parameters (to handle 1702 files efficiently)
    MAX_FILES_PER_FOLDER_GOOD = 50  # Limit good files per folder
    MAX_FILES_PER_FOLDER_BAD = 50   # Limit bad files per folder

    # Data split
    TEST_SIZE = 0.20
    VAL_SIZE = 0.20  # 20% of remaining data after test split

    # Batch size
    BATCH_SIZE = 128  # Larger batch for A100

    # Random seed
    RANDOM_SEED = 42

# ============= Data Loader Class =============
class CNCH5DataLoaderOptimized:
    """
    Optimized H5 data loader for Colab environment
    Handles large number of files efficiently
    """

    def __init__(self, config=DataConfig):
        self.config = config
        self.base_path = Path(config.BASE_PATH)
        self.window_size = config.WINDOW_SIZE
        self.stride = config.STRIDE
        self.scaler = StandardScaler()

        print("Data Loader Configuration:")
        print(f"  Base Path: {self.base_path}")
        print(f"  Window Size: {self.window_size}")
        print(f"  Stride: {self.stride}")
        print(f"  Max Good Files/Folder: {config.MAX_FILES_PER_FOLDER_GOOD}")
        print(f"  Max Bad Files/Folder: {config.MAX_FILES_PER_FOLDER_BAD}")
        print()

    def load_h5_file(self, h5_path):
        """
        Load data from a single H5 file
        Returns: numpy array of shape (n_samples, 3) or None if failed
        """
        try:
            with h5py.File(h5_path, "r") as f:
                # Based on verification, data is in 'vibration_data' key
                if "vibration_data" in f.keys():
                    data = f["vibration_data"][:]

                    # Data should be (n_samples, 3)
                    if len(data.shape) == 2 and data.shape[1] == 3:
                        return data.astype(np.float32)
                    elif len(data.shape) == 2:
                        # Take first 3 columns if more than 3
                        return data[:, :3].astype(np.float32)

                # Fallback: try to find any dataset
                for key in f.keys():
                    if isinstance(f[key], h5py.Dataset):
                        data = f[key][:]
                        if len(data.shape) == 2 and data.shape[1] >= 3:
                            return data[:, :3].astype(np.float32)
                        elif len(data.shape) == 1:
                            # Single channel, replicate to 3 channels
                            return np.column_stack([data, data, data]).astype(np.float32)

                return None

        except Exception as e:
            print(f"  Warning: Failed to load {h5_path.name}: {e}")
            return None

    def load_experiment_folder(self, exp_folder):
        """
        Load data from one experiment folder (M01, M02, or M03)
        Returns: (signals, labels) or (None, None) if failed
        """
        exp_path = self.base_path / exp_folder

        if not exp_path.exists():
            print(f"  Warning: Folder {exp_folder} not found")
            return None, None

        print(f"Loading {exp_folder}...")

        # Find all H5 files
        h5_files = list(exp_path.rglob("*.h5"))

        if not h5_files:
            print(f"  No H5 files found in {exp_folder}")
            return None, None

        # Classify files
        good_files = []
        bad_files = []

        for h5_file in h5_files:
            path_str = str(h5_file).lower()
            if "bad" in path_str or "worn" in path_str:
                bad_files.append(h5_file)
            else:
                good_files.append(h5_file)

        print(f"  Found {len(good_files)} good files, {len(bad_files)} bad files")

        # Sample files to limit memory usage
        np.random.seed(self.config.RANDOM_SEED)

        if len(good_files) > self.config.MAX_FILES_PER_FOLDER_GOOD:
            good_files = np.random.choice(
                good_files,
                self.config.MAX_FILES_PER_FOLDER_GOOD,
                replace=False
            ).tolist()
            print(f"  Sampled {len(good_files)} good files")

        if len(bad_files) > self.config.MAX_FILES_PER_FOLDER_BAD:
            bad_files = np.random.choice(
                bad_files,
                self.config.MAX_FILES_PER_FOLDER_BAD,
                replace=False
            ).tolist()
            print(f"  Sampled {len(bad_files)} bad files")

        # Load files
        all_signals = []
        all_labels = []

        # Load good files
        good_loaded = 0
        for h5_file in good_files:
            signals = self.load_h5_file(h5_file)
            if signals is not None:
                all_signals.append(signals)
                all_labels.append(np.zeros(len(signals)))
                good_loaded += 1

        # Load bad files
        bad_loaded = 0
        for h5_file in bad_files:
            signals = self.load_h5_file(h5_file)
            if signals is not None:
                all_signals.append(signals)
                all_labels.append(np.ones(len(signals)))
                bad_loaded += 1

        print(f"  Successfully loaded {good_loaded} good, {bad_loaded} bad files")

        if not all_signals:
            return None, None

        # Combine all signals
        combined_signals = np.vstack(all_signals)
        combined_labels = np.hstack(all_labels)

        print(f"  Combined shape: {combined_signals.shape}")
        print(f"  Labels: {len(combined_labels)} ({np.sum(combined_labels)} anomalies)")
        print()

        return combined_signals, combined_labels.astype(int)

    def create_windows(self, signals, labels):
        """
        Create sliding windows from continuous signals
        Returns: (windows, window_labels)
        """
        if len(signals) < self.window_size:
            print(f"  Warning: Signal length {len(signals)} < window size {self.window_size}")
            return np.array([]), np.array([])

        windows = []
        window_labels = []

        for i in range(0, len(signals) - self.window_size + 1, self.stride):
            window = signals[i:i + self.window_size]
            # Window is anomaly if >30% of points are anomalies
            window_label = int(np.mean(labels[i:i + self.window_size]) > 0.3)
            windows.append(window)
            window_labels.append(window_label)

        return np.array(windows), np.array(window_labels)

    def load_all_data(self):
        """
        Load all data from M01, M02, M03
        Returns: (X_train, y_train), (X_val, y_val), (X_test, y_test)
        """
        print("=" * 80)
        print("LOADING CNC H5 DATASET")
        print("=" * 80)
        print()

        all_windows = []
        all_labels = []

        # Load each experiment folder
        for exp_folder in ["M01", "M02", "M03"]:
            signals, labels = self.load_experiment_folder(exp_folder)

            if signals is not None:
                print(f"Creating windows for {exp_folder}...")
                windows, window_labels = self.create_windows(signals, labels)

                if len(windows) > 0:
                    all_windows.append(windows)
                    all_labels.append(window_labels)
                    print(f"  Created {len(windows)} windows, {np.sum(window_labels)} anomalies")
                    print()

        if not all_windows:
            raise ValueError("No data could be loaded! Please check the data path.")

        # Combine all data
        X = np.vstack(all_windows)
        y = np.hstack(all_labels)

        print("=" * 80)
        print("DATA SUMMARY")
        print("=" * 80)
        print(f"Total samples: {len(X)}")
        print(f"Total anomalies: {np.sum(y)} ({100*np.sum(y)/len(y):.2f}%)")
        print(f"Data shape: {X.shape}")
        print(f"Memory usage: {X.nbytes / 1024**2:.2f} MB")
        print()

        # Normalize data
        print("Normalizing data...")
        X_reshaped = X.reshape(-1, 3)
        X_normalized = self.scaler.fit_transform(X_reshaped)
        X = X_normalized.reshape(-1, self.window_size, 3)
        print("  Normalization complete")
        print()

        # Split data
        print("Splitting data...")
        y = y.astype(int)

        # First split: separate test set
        X_temp, X_test, y_temp, y_test = train_test_split(
            X, y,
            test_size=self.config.TEST_SIZE,
            stratify=y,
            random_state=self.config.RANDOM_SEED
        )

        # Second split: separate train and validation
        val_size_adjusted = self.config.VAL_SIZE / (1 - self.config.TEST_SIZE)
        X_train, X_val, y_train, y_val = train_test_split(
            X_temp, y_temp,
            test_size=val_size_adjusted,
            stratify=y_temp,
            random_state=self.config.RANDOM_SEED
        )

        print(f"  Train set: {len(X_train)} samples ({np.sum(y_train)} anomalies, {100*np.sum(y_train)/len(y_train):.2f}%)")
        print(f"  Val set:   {len(X_val)} samples ({np.sum(y_val)} anomalies, {100*np.sum(y_val)/len(y_val):.2f}%)")
        print(f"  Test set:  {len(X_test)} samples ({np.sum(y_test)} anomalies, {100*np.sum(y_test)/len(y_test):.2f}%)")
        print()

        return (X_train, y_train), (X_val, y_val), (X_test, y_test)

# ============= PyTorch Dataset =============
class CNCDataset(Dataset):
    """PyTorch Dataset for CNC data"""

    def __init__(self, X, y):
        self.X = torch.FloatTensor(X)
        self.y = torch.LongTensor(y)

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

# ============= Data Loader Creation =============
def get_data_loaders(config=DataConfig):
    """
    Create train, validation, and test data loaders
    Returns: train_loader, val_loader, test_loader
    """
    # Load data
    loader = CNCH5DataLoaderOptimized(config)
    (X_train, y_train), (X_val, y_val), (X_test, y_test) = loader.load_all_data()

    # Create datasets
    train_dataset = CNCDataset(X_train, y_train)
    val_dataset = CNCDataset(X_val, y_val)
    test_dataset = CNCDataset(X_test, y_test)

    print("=" * 80)
    print("CREATING DATA LOADERS")
    print("=" * 80)

    # Handle class imbalance with weighted sampling
    train_targets = y_train.astype(int)
    class_counts = np.bincount(train_targets)
    class_weights = 1.0 / class_counts
    sample_weights = class_weights[train_targets]

    sampler = WeightedRandomSampler(
        weights=sample_weights,
        num_samples=len(sample_weights),
        replacement=True
    )

    print(f"Class distribution in training set:")
    print(f"  Normal (0): {class_counts[0]} samples")
    print(f"  Anomaly (1): {class_counts[1]} samples")
    print(f"  Class weights: Normal={class_weights[0]:.4f}, Anomaly={class_weights[1]:.4f}")
    print()

    # Create data loaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=config.BATCH_SIZE,
        sampler=sampler,
        num_workers=2,
        pin_memory=True
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=config.BATCH_SIZE,
        shuffle=False,
        num_workers=2,
        pin_memory=True
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=config.BATCH_SIZE,
        shuffle=False,
        num_workers=2,
        pin_memory=True
    )

    print(f"Data loaders created:")
    print(f"  Train: {len(train_loader)} batches")
    print(f"  Val:   {len(val_loader)} batches")
    print(f"  Test:  {len(test_loader)} batches")
    print(f"  Batch size: {config.BATCH_SIZE}")
    print()

    return train_loader, val_loader, test_loader

# ============= Main Test Function =============
def test_data_loading():
    """Test data loading functionality"""
    print("=" * 80)
    print("TESTING DATA LOADING MODULE")
    print("=" * 80)
    print()

    try:
        # Create data loaders
        train_loader, val_loader, test_loader = get_data_loaders()

        # Test one batch
        print("=" * 80)
        print("TESTING BATCH LOADING")
        print("=" * 80)

        for batch_x, batch_y in train_loader:
            print(f"Batch shape: {batch_x.shape}")
            print(f"Labels shape: {batch_y.shape}")
            print(f"Batch data type: {batch_x.dtype}")
            print(f"Labels data type: {batch_y.dtype}")
            print(f"Label distribution in batch: {torch.bincount(batch_y)}")
            print()
            break

        print("=" * 80)
        print("DATA LOADING TEST SUCCESSFUL!")
        print("=" * 80)
        print()
        print("✓ All data loaded correctly")
        print("✓ Data loaders created successfully")
        print("✓ Ready to proceed to Module 3 (Model Definition)")

        return train_loader, val_loader, test_loader

    except Exception as e:
        print(f"ERROR during data loading: {e}")
        import traceback
        traceback.print_exc()
        return None, None, None

# ============= Run Test =============
if __name__ == "__main__":
    # Test the data loading
    train_loader, val_loader, test_loader = test_data_loading()